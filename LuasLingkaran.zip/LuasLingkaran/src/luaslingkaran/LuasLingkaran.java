
package luaslingkaran;

public class LuasLingkaran {
    public static void main(String[] args) {
       double jarijari = 6;
       double phi= 3.14;
       double luasLingkaran= phi*jarijari*jarijari;
       System.out.println("jarijari ="+jarijari);
       System.out.println("phi ="+phi);
       System.out.println("Luas Lingkaran Adalah ="+luasLingkaran);
    }
}
